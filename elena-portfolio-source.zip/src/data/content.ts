import portrait from '../assets/portrait.jpg'
import mtnAutumn from '../assets/mtn-autumn.jpg'
import mtnLake from '../assets/mtn-lake.jpg'
import mtnSnow from '../assets/mtn-snow.jpg'
import paintStage from '../assets/paint-stage.jpg'
import paintCard from '../assets/paint-card.jpg'
import judoMedals from '../assets/judo-medals.jpg'

// ─────────────────────────────────────────────────────────────
//  All site content lives here. Edit this file to update the site.
//  Images: set `image` to a path/URL to replace any placeholder.
// ─────────────────────────────────────────────────────────────

export const profile = {
  name: 'Elena Poposka',
  headline: ['Curious by nature.', 'Technical by education.', 'Creative by instinct.'],
  motto: 'Stay curious. Build things. Explore beyond the obvious.',
  intro:
    'Computer Science graduate from Skopje, working where software, machine learning and people meet.',
  email: 'elena.poposka01@gmail.com',
  linkedin: 'https://www.linkedin.com/in/elena-poposka-304aa123b/',
  github: 'https://github.com/elenaPoposkaa',
  location: 'Skopje, North Macedonia',
  // Put your CV in /public and set the file name here (e.g. '/Elena_Poposka_CV.pdf').
  // While this is empty, the "Download CV" button is hidden instead of leading nowhere.
  cvUrl: './Elena_Poposka_CV.pdf',
  // Put a portrait in /public and set it here (e.g. '/elena.jpg').
  portrait,
}

export const nav = [
  { label: 'About', href: '#about' },
  { label: 'Work', href: '#work' },
  { label: 'Experience', href: '#experience' },
  { label: 'Beyond code', href: '#beyond' },
  { label: 'Contact', href: '#contact' },
]

export const about = {
  title: 'I like knowing how things work, and why people use them.',
  paragraphs: [
    'I studied Computer Science and Engineering at Ss. Cyril and Methodius University in Skopje, and graduated in May 2026. Along the way I kept wandering: into machine learning, language models and data, but also into marketing, business and the question of why one digital product feels effortless and another does not.',
    'That wandering turned out to be the point. I build things end to end, from a messy dataset or a vague idea to an API and an interface someone can actually use. And I am just as interested in the human side: explaining technical work to people who do not code, coordinating volunteers, writing for an audience.',
    'Right now I am looking for a team where I can learn from real product work, ask good questions and ship.',
  ],
  facts: [
    ['Degree', 'B.Sc. Computer Science and Engineering'],
    ['University', 'Ss. Cyril and Methodius, Skopje'],
    ['Graduated', 'May 2026'],
    ['GPA', '3.5 / 4.0'],
    ['Languages', 'Macedonian, English (C1), learning Spanish'],
  ],
}

export interface Project {
  id: string
  index: string
  title: string
  kind: string
  date: string
  summary: string
  problem: string
  approach: string
  implementation: string[]
  contribution: string
  stack: string[]
  links: { label: string; href: string }[]
  visual: 'parser' | 'glucose' | 'search' | 'delivery' | 'fitness'
}

export const projects: Project[] = [
  {
    id: 'resume-parser',
    index: '01',
    title: 'AI-Powered Resume Parser',
    kind: 'Full-stack AI web application',
    date: 'Nov 2025',
    summary: 'Turns unstructured resumes into structured candidate data with an LLM.',
    problem:
      'Resumes arrive in every shape and layout. Reading them into a consistent, structured form by hand is slow and repetitive.',
    approach:
      'An end-to-end pipeline that uses LLM-based NLP to extract structured candidate information, designed around clear data contracts so models can be swapped later.',
    implementation: [
      'Integrated the Google Gemini API, using prompt engineering to extract structured candidate information.',
      'Designed scalable backend services and ML-ready data contracts as JSON schemas.',
      'Built a modular full-stack system with Spring Boot and React, enabling future model integration.',
    ],
    contribution: 'Individual project, designed and built end to end.',
    stack: ['Google Gemini API', 'Prompt engineering', 'Spring Boot', 'React', 'JSON schemas'],
    links: [
      { label: 'Backend', href: 'https://github.com/elenaPoposkaa/resume-parser-backend' },
      { label: 'Frontend', href: 'https://github.com/elenaPoposkaa/resume-parse-frontend' },
    ],
    visual: 'parser',
  },
  {
    id: 'diabetes-ml',
    index: '02',
    title: 'Diabetes Risk & Glucose Prediction System',
    kind: 'Machine learning project',
    date: 'Jan 2026',
    summary: 'Predicts missing glucose values and classifies diabetes outcomes.',
    problem:
      'Real health datasets contain missing and invalid values, and a prediction is only useful if you can understand what drove it.',
    approach:
      'An end-to-end pipeline that predicts missing glucose values and classifies diabetes outcomes, with uncertainty-aware training and interpretability built in.',
    implementation: [
      'Applied Active Learning with NGBoost, using uncertainty-based sampling to iteratively improve regression performance.',
      'Trained a TabNet deep learning model on tabular data and extracted feature importances for interpretability.',
      'Handled preprocessing, invalid-value imputation, evaluation (R²) and visualization with Python, Pandas, PyTorch and scikit-learn.',
    ],
    contribution: 'Individual project, from data preparation to evaluation.',
    stack: ['Python', 'PyTorch', 'scikit-learn', 'Pandas', 'NGBoost', 'TabNet'],
    links: [{ label: 'GitHub', href: 'https://github.com/elenaPoposkaa/diabetes-ml-project' }],
    visual: 'glucose',
  },
  {
    id: 'retrieval-assistant',
    index: '03',
    title: 'Retrieval Assistant',
    kind: 'Semantic search NLP system',
    date: 'Jan 2026',
    summary: 'Multilingual semantic search for customer support questions.',
    problem:
      'Customer support questions come in many languages and many phrasings, so keyword search misses what people actually mean.',
    approach:
      'A semantic search assistant that matches meaning rather than words, using sentence embeddings and cosine similarity over a knowledge base.',
    implementation: [
      'Precomputed multilingual embeddings with sentence-transformers to enable fast top-k retrieval.',
      'Developed a FastAPI backend with a real-time /ask endpoint for querying the knowledge base.',
      'Implemented confidence scoring and scalable indexing for production-style deployment.',
    ],
    contribution: 'Individual project, from embeddings to API.',
    stack: ['Python', 'sentence-transformers', 'FastAPI', 'Cosine similarity', 'NLP'],
    links: [{ label: 'GitHub', href: 'https://github.com/elenaPoposkaa/faq-retrieval-assistant' }],
    visual: 'search',
  },
  {
    id: 'food-delivery',
    index: '04',
    title: 'Food Delivery Web Application',
    kind: 'Full-stack web application',
    date: 'Apr – Jun 2025',
    summary: 'Manages food delivery orders across users, dishes and orders.',
    problem: 'A delivery service needs one reliable place to manage users, dishes and orders.',
    approach:
      'A full-stack application with a React frontend and a layered Spring Boot backend, built for a university course at the Faculty of Computer Science and Engineering.',
    implementation: [
      'Built the frontend in React with modular components, hooks and context for state management.',
      'Implemented Spring Boot backend services with a layered architecture (controller, service, repository) and secure authentication.',
      'Connected a SQL database for persistent storage, with RESTful communication through Axios.',
    ],
    contribution: 'Frontend, backend and database integration.',
    stack: ['React', 'Spring Boot', 'SQL', 'Axios', 'REST'],
    links: [],
    visual: 'delivery',
  },
  {
    id: 'fitness-app',
    index: '05',
    title: 'Fitness Tracking Mobile App',
    kind: 'Cross-platform mobile application',
    date: 'Oct 2024 – Jan 2025',
    summary: 'A Flutter app with authentication, location and camera features.',
    problem: 'Tracking fitness on a phone should feel smooth across every screen.',
    approach:
      'A cross-platform Flutter app with both front-end and back-end functionality, created as a university project at the Faculty of Computer Science and Engineering.',
    implementation: [
      'Implemented state management, user authentication and integration with RESTful web services.',
      'Added location and camera features.',
      'Designed custom UI components and smooth navigation across multiple screens, with clear project documentation.',
    ],
    contribution: 'Front-end and back-end functionality, UI components and documentation.',
    stack: ['Flutter', 'REST APIs', 'State management', 'Authentication'],
    links: [],
    visual: 'fitness',
  },
]

export interface Role {
  period: string
  title: string
  org: string
  kind: 'tech' | 'business' | 'leadership'
  points: string[]
}

export const experience: Role[] = [
  {
    period: 'Jun – Sep 2026',
    title: 'Marketing & Sales Assistant Intern',
    org: 'Dynamic Development Solutions (DDS), Skopje',
    kind: 'business',
    points: [
      'Supported the website and social media content, strengthening brand visibility for an IT consulting firm.',
      'Assisted with client outreach and lead generation to move prospects through the sales pipeline.',
      'Researched markets and competitors to identify opportunities and shape outreach strategy.',
      'Translated technical solutions into clear value for non-technical clients.',
    ],
  },
  {
    period: 'Mar – Jun 2026',
    title: 'Software Engineer Intern',
    org: 'Ministry of Internal Affairs of North Macedonia, Skopje',
    kind: 'tech',
    points: [
      'Contributed to software solutions alongside experienced engineers across the full development lifecycle.',
      'Wrote and optimized SQL queries and performed data analysis to support team goals.',
      'Tested software to find defects and verify functionality, improving reliability.',
      'Troubleshot and resolved technical issues in an Agile team.',
    ],
  },
  {
    period: 'May 2021 – Jun 2024',
    title: 'Project Coordinator',
    org: 'Go Green, Association for Sustainability and Environmental Protection',
    kind: 'leadership',
    points: [
      'Led initiatives on sustainable development and environmental awareness in local communities.',
      'Coordinated eco-campaigns, educational workshops and volunteer programs on recycling and renewable energy.',
      'Managed volunteers and worked with local institutions on community projects.',
      'Recruited and mentored new members, increasing participation by over 30%.',
    ],
  },
  {
    period: 'Youth leadership',
    title: 'Youth Project Member / Coordinator',
    org: 'ODAS, Organization for Dialogue and Affirmation of High School and University Students',
    kind: 'leadership',
    points: [
      'Coordinated youth-led projects on dialogue, leadership and civic engagement.',
      'Organized workshops, campaigns and events on education and student rights.',
      'Collaborated with schools, media and NGOs to strengthen student participation.',
      'Created social media and blog content, and helped build a nationwide network of young leaders.',
    ],
  },
]

export interface Entry {
  id: string
  tag: string
  title: string
  note: string
  image: string
  alt: string
  pos?: string
  span: string
}

export const journal: Entry[] = [
  {
    id: 'paint-card',
    tag: 'Acrylic & oil',
    title: 'Сончева рефлексија',
    note: 'My painting, printed for the Sparkasse Life art event. Second place in 2024, and the painting was later sold at auction.',
    image: paintCard,
    alt: 'A printed card showing the painting Sončeva refleksija by Elena Poposka',
    span: 'md:col-span-4 md:row-span-2',
  },
  {
    id: 'paint-stage',
    tag: 'Painting',
    title: 'On the big screen',
    note: 'Seeing the painting presented on stage was a strange, wonderful moment for something made quietly at home.',
    image: paintStage,
    alt: 'A stage at an awards event with the painting shown on a large screen',
    pos: '50% 40%',
    span: 'md:col-span-4 md:row-span-2',
  },
  {
    id: 'judo',
    tag: 'Judo',
    title: 'Years on the mat',
    note: 'Judo taught me focus under pressure and how to get back up. I represented North Macedonia on the national team.',
    image: judoMedals,
    alt: 'Judo medals worn over a blue judogi with a green belt',
    pos: '45% 45%',
    span: 'md:col-span-4 md:row-span-2',
  },
  {
    id: 'mtn-autumn',
    tag: 'Hiking',
    title: 'Autumn ridge',
    note: 'Where I think best: uphill, quiet, and a view at the end.',
    image: mtnAutumn,
    alt: 'Autumn aspen trees and a cabin below a blue mountain range',
    span: 'md:col-span-4 md:row-span-2',
  },
  {
    id: 'mtn-lake',
    tag: 'Travel',
    title: 'Lake and granite',
    note: 'Clear water, hard rock, and clouds that never hold still.',
    image: mtnLake,
    alt: 'A clear mountain lake with dark peaks and white clouds',
    span: 'md:col-span-4 md:row-span-2',
  },
  {
    id: 'mtn-snow',
    tag: 'Skiing',
    title: 'Storm light',
    note: 'Snow, shadow and a ridge line I could look at for hours.',
    image: mtnSnow,
    alt: 'Snow covered mountain ridges under heavy grey clouds',
    span: 'md:col-span-4 md:row-span-2',
  },
]

export const alsoInto = ['Running', 'Traveling', 'Photography', 'Learning Spanish', 'Psychology and human behavior']

export const curiosities = [
  'Why do some products feel obvious, and others feel like work?',
  'What does a model actually pay attention to?',
  'How do people make decisions when nobody is watching?',
  'What changes when you explain an idea to a non-expert?',
  'How does a mountain look different every hour?',
  'What is the story behind a word in another language?',
]

export const skills: { group: string; note: string; items: string[] }[] = [
  { group: 'Programming', note: 'Languages & UI frameworks', items: ['Python', 'Java', 'JavaScript', 'C++', 'C#', 'React', 'Flutter'] },
  { group: 'AI / ML', note: 'Models & language', items: ['TensorFlow', 'PyTorch', 'Keras', 'Scikit-learn', 'NLP', 'LLMs', 'Transformers'] },
  { group: 'Data', note: 'Storage, analysis, reporting', items: ['SQL', 'MySQL', 'PostgreSQL', 'Pandas', 'NumPy', 'Tableau', 'Power BI', 'Excel'] },
  { group: 'Tools', note: 'Frameworks & craft', items: ['Spring Boot', 'FastAPI', 'Git', 'Adobe Suite', 'Matplotlib', 'Seaborn'] },
]
