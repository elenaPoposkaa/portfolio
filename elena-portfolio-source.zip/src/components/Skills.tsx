import { useState } from 'react'
import { motion } from 'framer-motion'
import { skills } from '../data/content'
import { Reveal, SectionHead } from './ui'

export default function Skills() {
  const [g, setG] = useState<string | null>(null)
  return (
    <section id="skills" className="mx-auto max-w-[1400px] px-6 md:px-10 py-28 md:py-40">
      <SectionHead no="05" title="Toolbox" />
      <div onMouseLeave={() => setG(null)}>
        {skills.map((s) => (
          <motion.div key={s.group} onMouseEnter={() => setG(s.group)} onFocus={() => setG(s.group)} onBlur={() => setG(null)} animate={{ opacity: g === null || g === s.group ? 1 : 0.28 }} transition={{ duration: 0.4 }}
            className="grid md:grid-cols-12 gap-4 md:gap-8 py-9 md:py-12 border-t hair last:border-b">
            <div className="md:col-span-3"><h3 className="font-display text-4xl md:text-5xl leading-none">{s.group}</h3><p className="label mt-3">{s.note}</p></div>
            <ul className="md:col-span-9 flex flex-wrap items-baseline gap-x-5 gap-y-2 font-display text-[clamp(26px,3.6vw,52px)] leading-[1.1]">
              {s.items.map((it, i) => (
                <Reveal key={it} delay={i * 0.04}>
                  <li tabIndex={0} className="hover:text-clay focus:text-clay transition-colors cursor-default" data-hover>{it}{i < s.items.length - 1 && <span className="text-ink/25 ml-5">/</span>}</li>
                </Reveal>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
