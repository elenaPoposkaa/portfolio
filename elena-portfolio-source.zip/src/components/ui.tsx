import { motion, useReducedMotion } from 'framer-motion'
import type { ReactNode } from 'react'

export function Reveal({ children, delay = 0, className = '', y = 32 }: { children: ReactNode; delay?: number; className?: string; y?: number }) {
  const reduce = useReducedMotion()
  return (
    <motion.div className={className} initial={reduce ? false : { opacity: 0, y }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-8% 0px' }} transition={{ duration: 0.9, delay, ease: [0.2, 0.8, 0.2, 1] }}>
      {children}
    </motion.div>
  )
}

/** Image-style reveal: a clay curtain wipes away. */
export function Curtain({ children, className = '' }: { children: ReactNode; className?: string }) {
  const reduce = useReducedMotion()
  return (
    <div className={`relative overflow-hidden ${className}`}>
      {children}
      {!reduce && (
        <motion.div aria-hidden className="absolute inset-0 bg-clay origin-top" initial={{ scaleY: 1 }}
          whileInView={{ scaleY: 0 }} viewport={{ once: true, margin: '-10% 0px' }} transition={{ duration: 1.1, ease: [0.76, 0, 0.24, 1] }} />
      )}
    </div>
  )
}

export function SectionHead({ no, title }: { no: string; title: string }) {
  return (
    <Reveal className="flex items-baseline gap-6 border-t hair pt-5 mb-14 md:mb-20">
      <span className="label">{no}</span>
      <span className="label text-ink">{title}</span>
    </Reveal>
  )
}
