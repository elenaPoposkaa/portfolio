import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowUpRight, Plus } from 'lucide-react'
import { projects } from '../data/content'
import { Reveal, SectionHead } from './ui'
import Visual from './Visual'

export default function Work() {
  const [open, setOpen] = useState<string | null>(projects[0].id)
  return (
    <section id="work" className="bg-ink text-paper">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10 py-28 md:py-40">
        <div className="[&_.label]:!text-paper/50 [&_.hair]:!border-paper/20"><SectionHead no="02" title="Selected work" /></div>
        <Reveal><h2 className="font-display text-[clamp(40px,7vw,104px)] leading-[0.95] tracking-[-0.02em] mb-16 md:mb-24 max-w-4xl">Five things I built, <span className="italic text-clay">and how.</span></h2></Reveal>
        <ul className="border-t border-paper/20">
          {projects.map((p) => {
            const isOpen = open === p.id
            return (
              <li key={p.id} className="border-b border-paper/20">
                <button onClick={() => setOpen(isOpen ? null : p.id)} aria-expanded={isOpen} aria-controls={`panel-${p.id}`} data-hover
                  className="group w-full text-left grid grid-cols-[48px_1fr_auto] md:grid-cols-[100px_1fr_260px_auto] gap-4 items-baseline py-7 md:py-9">
                  <span className="font-mono text-xs text-paper/50">{p.index}</span>
                  <span className="font-display text-[clamp(26px,3.8vw,56px)] leading-[1.05] transition-all duration-500 group-hover:translate-x-3 group-hover:text-clay">{p.title}</span>
                  <span className="hidden md:block label !text-paper/50">{p.kind} · {p.date}</span>
                  <Plus size={22} className={`transition-transform duration-500 ${isOpen ? 'rotate-45 text-clay' : ''}`} />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div id={`panel-${p.id}`} role="region" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.7, ease: [0.76, 0, 0.24, 1] }} className="overflow-hidden">
                      <div className="grid md:grid-cols-12 gap-10 pb-14 md:pl-[100px]">
                        <div className="md:col-span-5">
                          <div className="aspect-[10/7] bg-paper text-ink p-5 md:p-7"><Visual kind={p.visual} /></div>
                          <p className="label !text-paper/40 mt-3">Conceptual illustration, not a screenshot</p>
                        </div>
                        <div className="md:col-span-7 grid sm:grid-cols-2 gap-x-10 gap-y-8 text-[15px] leading-relaxed text-paper/80 content-start">
                          <p className="sm:col-span-2 font-display text-2xl md:text-3xl text-paper leading-snug">{p.summary}</p>
                          <div><h3 className="label !text-clay mb-2">Problem</h3><p>{p.problem}</p></div>
                          <div><h3 className="label !text-clay mb-2">Approach</h3><p>{p.approach}</p></div>
                          <div className="sm:col-span-2"><h3 className="label !text-clay mb-2">Technical implementation</h3>
                            <ul className="space-y-2">{p.implementation.map((i) => <li key={i} className="flex gap-3"><span className="text-clay">→</span><span>{i}</span></li>)}</ul></div>
                          <div><h3 className="label !text-clay mb-2">My contribution</h3><p>{p.contribution}</p></div>
                          <div><h3 className="label !text-clay mb-2">Technologies</h3><p className="flex flex-wrap gap-2">{p.stack.map((s) => <span key={s} className="border border-paper/25 px-2.5 py-1 text-xs font-mono">{s}</span>)}</p></div>
                          {p.links.length > 0 && (
                            <div className="sm:col-span-2 flex flex-wrap gap-6">
                              {p.links.map((l) => <a key={l.href} href={l.href} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 label !text-paper border-b border-paper pb-1 hover:!text-clay hover:border-clay">GitHub · {l.label} <ArrowUpRight size={14} /></a>)}
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </li>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
