import { useState } from 'react'
import { ArrowUpRight, Check, Copy, Download } from 'lucide-react'
import { profile } from '../data/content'
import { Reveal } from './ui'

export default function Contact() {
  const [copied, setCopied] = useState(false)
  const [note, setNote] = useState('')
  const copy = async () => {
    try { await navigator.clipboard.writeText(profile.email); setCopied(true); setTimeout(() => setCopied(false), 1800) } catch { setNote('Copy is blocked here. Select the address and copy it.') }
  }
  return (
    <section id="contact" className="bg-ink text-paper">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10 pt-28 md:pt-40 pb-10">
        <Reveal className="flex items-baseline gap-6 border-t border-paper/20 pt-5 mb-14 md:mb-20"><span className="label !text-paper/50">06</span><span className="label !text-paper">Contact</span></Reveal>
        <Reveal><h2 className="font-display text-[clamp(44px,9vw,148px)] leading-[0.92] tracking-[-0.03em]">Have an interesting idea? <span className="italic text-clay">Let’s make something meaningful.</span></h2></Reveal>

        <div className="mt-20 grid md:grid-cols-12 gap-12">
          <div className="md:col-span-8 space-y-6">
            <button onClick={copy} data-hover className="group flex items-center gap-4 text-left">
              <span className="font-display text-3xl md:text-4xl border-b border-paper/40 group-hover:border-clay group-hover:text-clay transition-colors break-all">{profile.email}</span>
              {copied ? <Check size={20} className="text-clay shrink-0" /> : <Copy size={20} className="shrink-0 opacity-60" />}
            </button>
            <p className="label !text-paper/50" aria-live="polite">{copied ? 'Copied to clipboard' : note || 'Click to copy'}</p>
            <div className="flex flex-wrap gap-x-8 gap-y-4 pt-4">
              <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 label !text-paper border-b border-paper pb-1 hover:!text-clay hover:border-clay">LinkedIn <ArrowUpRight size={14} /></a>
              <a href={profile.github} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 label !text-paper border-b border-paper pb-1 hover:!text-clay hover:border-clay">GitHub <ArrowUpRight size={14} /></a>
              {profile.cvUrl && <a href={profile.cvUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 label !text-paper border-b border-paper pb-1 hover:!text-clay hover:border-clay">Download CV <Download size={14} /></a>}
            </div>
          </div>
        </div>

        <div className="mt-28 pt-6 border-t border-paper/20 flex flex-wrap justify-between gap-4 label !text-paper/50">
          <span>© 2026 {profile.name}</span><span>{profile.motto}</span><a href="#top" className="hover:text-clay">Back to top ↑</a>
        </div>
      </div>
    </section>
  )
}
