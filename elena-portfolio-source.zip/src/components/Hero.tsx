import { useEffect, useRef } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { ArrowDownRight } from 'lucide-react'
import { profile } from '../data/content'

function DotField() {
  const ref = useRef<HTMLCanvasElement>(null)
  const reduce = useReducedMotion()
  useEffect(() => {
    const c = ref.current!, ctx = c.getContext('2d')!
    let w = 0, h = 0, raf = 0, mx = -999, my = -999, t = 0
    const dpr = Math.min(devicePixelRatio || 1, 2), gap = 30
    const resize = () => { const r = c.getBoundingClientRect(); w = r.width; h = r.height; c.width = w * dpr; c.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0) }
    const draw = () => {
      ctx.clearRect(0, 0, w, h); t += 0.012
      for (let x = gap / 2; x < w; x += gap) for (let y = gap / 2; y < h; y += gap) {
        const dx = x - mx, dy = y - my, d = Math.hypot(dx, dy), f = Math.max(0, 1 - d / 190)
        const wave = reduce ? 0 : Math.sin(x * 0.01 + t) * Math.cos(y * 0.012 + t) * 3
        const px = x + (d ? (dx / d) * f * f * 34 : 0), py = y + wave + (d ? (dy / d) * f * f * 34 : 0)
        ctx.beginPath(); ctx.arc(px, py, 1.3 + f * 3.4, 0, 6.3)
        ctx.fillStyle = f > 0.02 ? `rgba(200,71,43,${0.35 + f * 0.65})` : 'rgba(26,25,23,.22)'; ctx.fill()
      }
      raf = requestAnimationFrame(draw)
    }
    const move = (e: PointerEvent) => { const r = c.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top }
    const leave = () => { mx = my = -999 }
    resize(); addEventListener('resize', resize); addEventListener('pointermove', move); document.addEventListener('pointerleave', leave)
    raf = requestAnimationFrame(draw)
    return () => { cancelAnimationFrame(raf); removeEventListener('resize', resize); removeEventListener('pointermove', move); document.removeEventListener('pointerleave', leave) }
  }, [reduce])
  return <canvas ref={ref} aria-hidden className="absolute inset-0 w-full h-full touch-pan-y" />
}

function Letters({ text, delay = 0 }: { text: string; delay?: number }) {
  return (
    <span className="inline-block whitespace-nowrap" aria-hidden>
      {text.split('').map((ch, i) => (
        <span key={i} className="inline-block overflow-hidden align-bottom pb-[0.08em]">
          <motion.span className="inline-block hover:text-clay hover:-translate-y-2 transition-[color,transform] duration-300" data-hover
            initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ duration: 1, delay: delay + i * 0.045, ease: [0.2, 0.8, 0.2, 1] }}>
            {ch === ' ' ? ' ' : ch}
          </motion.span>
        </span>
      ))}
    </span>
  )
}

export default function Hero() {
  return (
    <section id="top" className="relative min-h-[100svh] pt-16 flex flex-col overflow-hidden">
      <DotField />
      <div className="relative mx-auto w-full max-w-[1400px] px-6 md:px-10 flex-1 flex flex-col justify-center pointer-events-none">
        <motion.figure initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.9 }} className="mb-8 md:mb-10 max-w-2xl">
          <blockquote className="font-display italic text-[clamp(20px,2.2vw,30px)] leading-snug">“Opportunities do not happen. You create them.”</blockquote>
          <figcaption className="label mt-2">Chris Grosser</figcaption>
        </motion.figure>
        <h1 aria-label={profile.name} className="font-display leading-[0.86] tracking-[-0.03em] text-[clamp(64px,15.5vw,230px)] pointer-events-auto">
          <Letters text="Elena" delay={0.2} />
          <br />
          <span className="md:ml-[12vw] italic"><Letters text="Poposka" delay={0.55} /></span>
        </h1>
        <div className="mt-10 md:mt-14 grid md:grid-cols-12 gap-8 items-end pointer-events-auto">
          <motion.div className="md:col-span-7 font-display text-[clamp(22px,3vw,40px)] leading-[1.15]" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.3, duration: 0.9 }}>
            {profile.headline.map((l, i) => <span key={l} className={`block ${i === 2 ? 'italic text-clay' : ''}`}>{l}</span>)}
          </motion.div>
          <motion.div className="md:col-span-4 md:col-start-9" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }}>
            <p className="text-[15px] leading-relaxed text-ink/75 max-w-sm">{profile.intro}</p>
            <a href="#work" className="mt-6 inline-flex items-center gap-2 label !text-ink border-b border-ink pb-1 hover:text-clay hover:border-clay">See selected work <ArrowDownRight size={14} /></a>
          </motion.div>
        </div>
      </div>
      <div className="relative border-t hair">
        <div className="mx-auto max-w-[1400px] px-6 md:px-10 py-4 flex justify-between label">
          <span>{profile.motto}</span><span className="hidden md:inline">Move your cursor</span>
        </div>
      </div>
    </section>
  )
}
