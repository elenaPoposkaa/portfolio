import { useState } from 'react'
import { motion } from 'framer-motion'
import { alsoInto, curiosities, journal } from '../data/content'
import { Curtain, Reveal, SectionHead } from './ui'

export default function Beyond() {
  const [hot, setHot] = useState<number | null>(null)
  return (
    <section id="beyond" className="bg-bone">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10 py-28 md:py-40">
        <SectionHead no="04" title="Beyond code" />
        <Reveal className="grid md:grid-cols-12 gap-6 mb-16 md:mb-24">
          <h2 className="md:col-span-8 font-display text-[clamp(40px,7vw,104px)] leading-[0.95] tracking-[-0.02em]">Pages from <span className="italic text-clay">a journal.</span></h2>
          <p className="md:col-span-3 md:col-start-10 self-end text-[15px] leading-relaxed text-ink/70">The part of me that does not fit on a CV: mountains, paint, motion, and language.</p>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-5 md:auto-rows-[200px]">
          {journal.map((e, i) => (
            <Reveal key={e.id} delay={(i % 3) * 0.08} className={e.span}>
              <article data-hover className="group relative h-full min-h-[340px] overflow-hidden bg-ink">
                <div className="absolute inset-0"><Curtain className="h-full w-full">
                  <img src={e.image} alt={e.alt} loading="lazy" style={{ objectPosition: e.pos }} className="w-full h-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-105" />
                </Curtain></div>
                <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="relative h-full p-6 flex flex-col justify-between text-paper">
                  <span className="font-mono text-[11px] uppercase tracking-[0.18em] opacity-90">{e.tag}</span>
                  <div>
                    <h3 className="font-display text-3xl md:text-4xl leading-none">{e.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed max-w-md opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500 max-md:opacity-100 max-md:translate-y-0">{e.note}</p>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-10 flex flex-wrap items-baseline gap-x-4 gap-y-2"><span className="label">Also</span>{alsoInto.map((a, i) => <span key={a} className="font-display text-2xl md:text-3xl">{a}{i < alsoInto.length - 1 && <span className="text-ink/25 ml-4">/</span>}</span>)}</Reveal>

        <div className="mt-28 md:mt-40 grid md:grid-cols-12 gap-10">
          <Reveal className="md:col-span-4"><p className="label mb-3">A small list</p><h3 className="font-display text-4xl md:text-5xl leading-tight">Things that make me <span className="italic text-clay">curious.</span></h3></Reveal>
          <ul className="md:col-span-8 border-t border-ink/20" onMouseLeave={() => setHot(null)}>
            {curiosities.map((c, i) => (
              <motion.li key={c} onMouseEnter={() => setHot(i)} animate={{ opacity: hot === null || hot === i ? 1 : 0.3, x: hot === i ? 14 : 0 }} transition={{ duration: 0.35 }}
                className="flex gap-5 items-baseline py-5 border-b border-ink/20 font-display text-2xl md:text-3xl leading-snug" data-hover>
                <span className="font-mono text-xs text-clay">{String(i + 1).padStart(2, '0')}</span>{c}
              </motion.li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
