import { motion, useReducedMotion } from 'framer-motion'
import type { Project } from '../data/content'

const S = { stroke: '#1A1917', strokeWidth: 1.4, fill: 'none', strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const }
const C = '#C8472B'

export default function Visual({ kind }: { kind: Project['visual'] }) {
  const reduce = useReducedMotion()
  const draw = (d = 0) => reduce ? {} : { initial: { pathLength: 0 }, whileInView: { pathLength: 1 }, viewport: { once: true }, transition: { duration: 1.4, delay: d, ease: 'easeInOut' as const } }
  const pop = (d = 0) => reduce ? {} : { initial: { opacity: 0, scale: 0.4 }, whileInView: { opacity: 1, scale: 1 }, viewport: { once: true }, transition: { delay: d, duration: 0.5 } }
  return (
    <svg viewBox="0 0 400 280" className="w-full h-full" role="img" aria-label={`Conceptual illustration for ${kind}`}>
      {kind === 'parser' && (<g>
        <rect x="40" y="40" width="120" height="180" rx="3" {...S} />
        {[70, 90, 104, 118, 150, 164, 178].map((y, i) => <motion.line key={y} x1="56" x2={i % 3 === 0 ? 110 : 144} y1={y} y2={y} {...S} {...draw(i * 0.08)} />)}
        <motion.path d="M176 130 H 226" {...S} stroke={C} {...draw(0.5)} /><path d="M218 122 l10 8 -10 8" {...S} stroke={C} />
        <text x="244" y="76" fontFamily="JetBrains Mono" fontSize="20" fill={C}>{'{'}</text>
        {[['name', 104], ['skills', 128], ['experience', 152], ['education', 176]].map(([k, y], i) => (
          <motion.g key={k as string} {...pop(0.6 + i * 0.12)}><text x="262" y={y as number} fontFamily="JetBrains Mono" fontSize="12" fill="#1A1917">"{k}": …</text></motion.g>))}
        <text x="244" y="206" fontFamily="JetBrains Mono" fontSize="20" fill={C}>{'}'}</text>
      </g>)}
      {kind === 'glucose' && (<g>
        <path d="M40 230 H 370 M40 230 V 40" {...S} />
        <motion.path d="M50 190 C 120 170, 170 120, 240 100 S 330 70, 362 60 L 362 110 C 330 120, 290 140, 240 150 S 120 210, 50 215 Z" fill={C} fillOpacity=".14" stroke="none" {...pop(0.2)} />
        <motion.path d="M50 202 C 120 190, 170 135, 240 125 S 330 90, 362 85" {...S} stroke={C} strokeWidth={2} {...draw()} />
        {[[70,196],[100,188],[130,170],[165,150],[195,140],[225,118],[260,122],[295,100],[330,96]].map(([x, y], i) => <motion.circle key={i} cx={x} cy={y} r="3.4" fill="#1A1917" {...pop(0.4 + i * 0.06)} />)}
        <text x="42" y="256" fontFamily="JetBrains Mono" fontSize="10" fill="#7A746A">value · uncertainty band</text>
      </g>)}
      {kind === 'search' && (<g>
        {[[80,70],[120,200],[300,60],[340,190],[90,140],[320,130],[210,40],[220,235],[60,225],[370,90]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="3.4" fill="#1A1917" opacity=".3" />)}
        {[0, 1, 2].map((i) => <motion.circle key={i} cx="200" cy="140" r={40 + i * 36} {...S} strokeDasharray="3 6" opacity={0.5 - i * 0.12} {...draw(i * 0.2)} />)}
        {[[170,110],[235,125],[190,180]].map(([x, y], i) => <motion.g key={i} {...pop(0.5 + i * 0.15)}><line x1="200" y1="140" x2={x} y2={y} {...S} stroke={C} /><circle cx={x} cy={y} r="6" fill={C} /></motion.g>)}
        <circle cx="200" cy="140" r="8" fill="#1A1917" /><text x="214" y="132" fontFamily="JetBrains Mono" fontSize="11">query</text>
        <text x="40" y="262" fontFamily="JetBrains Mono" fontSize="10" fill="#7A746A">nearest meaning · top-k</text>
      </g>)}
      {kind === 'delivery' && (<g>
        {[['React', 40, 'client'], ['Spring Boot', 150, 'controller · service · repository'], ['SQL', 260, 'users · dishes · orders']].map(([t, y, s], i) => (
          <motion.g key={t as string} {...pop(i * 0.2)}><rect x="70" y={y as number} width="260" height="64" rx="3" {...S} stroke={i === 1 ? C : '#1A1917'} /><text x="90" y={(y as number) + 28} fontFamily="Instrument Serif" fontSize="26">{t}</text><text x="90" y={(y as number) + 48} fontFamily="JetBrains Mono" fontSize="10" fill="#7A746A">{s}</text></motion.g>))}
        <path d="M200 104 V 150 M200 214 V 260" {...S} stroke={C} /><text x="212" y="132" fontFamily="JetBrains Mono" fontSize="10" fill={C}>REST · Axios</text>
      </g>)}
      {kind === 'fitness' && (<g>
        <rect x="140" y="20" width="120" height="240" rx="18" {...S} />
        <motion.path d="M160 210 C 175 170, 200 190, 205 150 S 230 110, 240 70" {...S} stroke={C} strokeWidth={2.2} {...draw(0.2)} />
        <motion.circle cx="240" cy="70" r="6" fill={C} {...pop(1.2)} />
        <circle cx="200" cy="240" r="7" {...S} />
        <rect x="156" y="36" width="88" height="16" rx="3" {...S} opacity=".4" />
        <text x="276" y="80" fontFamily="JetBrains Mono" fontSize="10" fill="#7A746A">location</text><text x="276" y="240" fontFamily="JetBrains Mono" fontSize="10" fill="#7A746A">camera</text>
        <text x="40" y="150" fontFamily="JetBrains Mono" fontSize="10" fill="#7A746A">Flutter</text>
      </g>)}
    </svg>
  )
}
