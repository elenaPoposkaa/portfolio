import { about, profile } from '../data/content'
import { Curtain, Reveal, SectionHead } from './ui'

export default function About() {
  return (
    <section id="about" className="mx-auto max-w-[1400px] px-6 md:px-10 py-28 md:py-40">
      <SectionHead no="01" title="About" />
      <div className="grid md:grid-cols-12 gap-12 md:gap-8">
        <div className="md:col-span-7">
          <Reveal><h2 className="font-display text-[clamp(34px,5.4vw,78px)] leading-[1.02] tracking-[-0.02em]">{about.title}</h2></Reveal>
          <div className="mt-12 md:ml-[16%] space-y-6 text-[17px] leading-[1.75] text-ink/80 max-w-xl">
            {about.paragraphs.map((p, i) => <Reveal key={i} delay={i * 0.08}><p className={i === 0 ? 'first-letter:font-display first-letter:text-6xl first-letter:float-left first-letter:mr-3 first-letter:leading-[0.8] first-letter:text-clay' : ''}>{p}</p></Reveal>)}
          </div>
        </div>
        <div className="md:col-span-4 md:col-start-9 md:pt-24">
          <Curtain className="aspect-[4/5] bg-bone">
            {profile.portrait ? (
              <img src={profile.portrait} alt="Elena Poposka" style={{ objectPosition: '50% 22%' }} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-stone [background:repeating-linear-gradient(135deg,transparent_0_14px,rgba(26,25,23,.06)_14px_15px)]">
                <span className="font-display text-7xl italic text-clay/80">E.P</span>
                <span className="label mt-3">Portrait placeholder</span>
              </div>
            )}
          </Curtain>
          <dl className="mt-8 text-sm">
            {about.facts.map(([k, v]) => (
              <Reveal key={k} className="flex justify-between gap-6 py-3 border-t hair"><dt className="label pt-0.5">{k}</dt><dd className="text-right">{v}</dd></Reveal>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
