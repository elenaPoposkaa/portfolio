import { useEffect, useRef } from 'react'
import { useReducedMotion } from 'framer-motion'

export default function Cursor() {
  const wrap = useRef<HTMLDivElement>(null)
  const dot = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()
  useEffect(() => {
    if (reduce || !matchMedia('(pointer:fine)').matches) return
    const w = wrap.current!, d = dot.current!
    let x = 0, y = 0, cx = 0, cy = 0, raf = 0
    const move = (e: MouseEvent) => {
      x = e.clientX; y = e.clientY; w.style.opacity = '1'
      const big = !!(e.target as HTMLElement).closest('a,button,input,textarea,[data-hover]')
      d.style.width = d.style.height = big ? '56px' : '14px'
      d.style.margin = big ? '-28px 0 0 -28px' : '-7px 0 0 -7px'
      d.style.opacity = big ? '.55' : '1'
    }
    const loop = () => { cx += (x - cx) * 0.2; cy += (y - cy) * 0.2; w.style.transform = `translate(${cx}px,${cy}px)`; raf = requestAnimationFrame(loop) }
    addEventListener('mousemove', move); raf = requestAnimationFrame(loop)
    return () => { removeEventListener('mousemove', move); cancelAnimationFrame(raf) }
  }, [reduce])
  return (
    <div ref={wrap} aria-hidden className="cursor-dot fixed left-0 top-0 z-[80] pointer-events-none opacity-0">
      <div ref={dot} className="rounded-full bg-clay mix-blend-multiply transition-[width,height,margin,opacity] duration-300" style={{ width: 14, height: 14, margin: '-7px 0 0 -7px' }} />
    </div>
  )
}
