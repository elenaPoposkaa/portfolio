import { useState } from 'react'
import { motion } from 'framer-motion'
import { experience } from '../data/content'
import { Reveal, SectionHead } from './ui'

const filters = [['all', 'All'], ['tech', 'Technical'], ['business', 'Business'], ['leadership', 'Leadership']] as const

export default function Experience() {
  const [f, setF] = useState<(typeof filters)[number][0]>('all')
  return (
    <section id="experience" className="mx-auto max-w-[1400px] px-6 md:px-10 py-28 md:py-40">
      <SectionHead no="03" title="Experience" />
      <div className="grid md:grid-cols-12 gap-10">
        <div className="md:col-span-4">
          <div className="md:sticky md:top-28">
            <Reveal><h2 className="font-display text-[clamp(36px,5vw,72px)] leading-[1] tracking-[-0.02em]">Code, clients <span className="italic text-clay">and communities.</span></h2></Reveal>
            <div role="group" aria-label="Filter experience" className="mt-10 flex flex-wrap gap-2">
              {filters.map(([k, l]) => (
                <button key={k} onClick={() => setF(k)} aria-pressed={f === k}
                  className={`font-mono text-[11px] uppercase tracking-widest px-3.5 py-2 border transition-colors ${f === k ? 'bg-ink text-paper border-ink' : 'border-ink/30 hover:border-ink'}`}>{l}</button>
              ))}
            </div>
          </div>
        </div>
        <ol className="md:col-span-8 relative md:pl-10">
          <span aria-hidden className="hidden md:block absolute left-0 top-2 bottom-2 w-px bg-ink/20" />
          {experience.map((r) => {
            const on = f === 'all' || f === r.kind
            return (
              <motion.li key={r.title} animate={{ opacity: on ? 1 : 0.18 }} transition={{ duration: 0.5 }} className="relative pb-14 last:pb-0">
                <span aria-hidden className={`hidden md:block absolute -left-[45px] top-2.5 w-[11px] h-[11px] rounded-full border border-ink transition-colors ${on ? 'bg-clay border-clay' : 'bg-paper'}`} />
                <Reveal>
                  <p className="label">{r.period}</p>
                  <h3 className="font-display text-3xl md:text-4xl mt-2 leading-tight">{r.title}</h3>
                  <p className="text-clay text-sm mt-1">{r.org}</p>
                  <ul className="mt-5 space-y-2.5 text-[15px] leading-relaxed text-ink/75 max-w-2xl">
                    {r.points.map((p) => <li key={p} className="flex gap-3"><span className="text-ink/30">—</span><span>{p}</span></li>)}
                  </ul>
                </Reveal>
              </motion.li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}
