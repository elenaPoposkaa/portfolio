import { useEffect, useState } from 'react'
import { AnimatePresence, motion, useScroll, useSpring } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { nav, profile } from '../data/content'

export default function Nav() {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('')
  const { scrollYProgress } = useScroll()
  const w = useSpring(scrollYProgress, { stiffness: 120, damping: 24 })

  useEffect(() => {
    const ids = nav.map((n) => n.href.slice(1))
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' },
    )
    ids.forEach((id) => { const el = document.getElementById(id); el && io.observe(el) })
    return () => io.disconnect()
  }, [])

  return (
    <>
      <motion.div style={{ scaleX: w }} className="fixed top-0 left-0 right-0 h-[2px] bg-clay origin-left z-[60]" />
      <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-sm bg-paper/70">
        <div className="mx-auto max-w-[1400px] px-6 md:px-10 h-16 flex items-center justify-between">
          <a href="#top" className="font-display text-2xl leading-none">E<span className="text-clay">.</span>P</a>
          <nav aria-label="Main" className="hidden md:flex gap-9">
            {nav.map((n) => (
              <a key={n.href} href={n.href} className={`label transition-colors hover:text-ink ${active === n.href.slice(1) ? 'text-ink' : ''}`}>
                {active === n.href.slice(1) && <span className="inline-block w-1.5 h-1.5 rounded-full bg-clay mr-2 align-middle" />}
                {n.label}
              </a>
            ))}
          </nav>
          <button className="md:hidden p-2 -mr-2" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ clipPath: 'inset(0 0 100% 0)' }} animate={{ clipPath: 'inset(0 0 0% 0)' }} exit={{ clipPath: 'inset(0 0 100% 0)' }}
            transition={{ duration: 0.6, ease: [0.76, 0, 0.24, 1] }} className="fixed inset-0 z-40 bg-ink text-paper pt-28 px-6 flex flex-col">
            {nav.map((n, i) => (
              <motion.a key={n.href} href={n.href} onClick={() => setOpen(false)} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.07 }}
                className="font-display text-5xl py-3 border-b border-paper/15">{n.label}</motion.a>
            ))}
            <p className="label !text-paper/50 mt-auto pb-8">{profile.email}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
