import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Nav from './components/Nav'
import Hero from './components/Hero'
import About from './components/About'
import Work from './components/Work'
import Experience from './components/Experience'
import Beyond from './components/Beyond'
import Skills from './components/Skills'
import Contact from './components/Contact'
import Cursor from './components/Cursor'

export default function App() {
  const [ready, setReady] = useState(false)
  useEffect(() => { const t = setTimeout(() => setReady(true), 1100); return () => clearTimeout(t) }, [])
  return (
    <>
      <AnimatePresence>
        {!ready && (
          <motion.div key="loader" className="fixed inset-0 z-[90] bg-ink text-paper flex items-center justify-center" exit={{ clipPath: 'inset(0 0 100% 0)' }} transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}>
            <motion.span initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="font-display text-5xl italic">Elena Poposka<span className="text-clay">.</span></motion.span>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="grain" aria-hidden />
      <Cursor />
      <Nav />
      <main>{ready && <Hero />}<About /><Work /><Experience /><Beyond /><Skills /></main>
      <Contact />
    </>
  )
}
