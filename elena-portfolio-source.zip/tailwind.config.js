export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: { paper: '#EFEAE0', ink: '#1A1917', clay: '#C8472B', stone: '#7A746A', bone: '#E3DCCD' },
      fontFamily: { display: ['"Instrument Serif"', 'Georgia', 'serif'], sans: ['"Space Grotesk"', 'system-ui', 'sans-serif'], mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'] },
    },
  },
  plugins: [],
}
